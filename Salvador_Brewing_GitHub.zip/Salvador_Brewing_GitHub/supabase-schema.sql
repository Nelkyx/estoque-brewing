-- Execute no SQL Editor do Supabase.
-- Crie usuários manualmente em Authentication > Users (desative cadastro público).
create table if not exists public.company_data (
  id text primary key,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.company_data enable row level security;
drop policy if exists "Equipe autenticada pode ler dados da empresa" on public.company_data;
drop policy if exists "Equipe autenticada pode salvar dados da empresa" on public.company_data;
create policy "Equipe autenticada pode ler dados da empresa"
on public.company_data for select to authenticated using (id = 'salvador-brewing');
create policy "Equipe autenticada pode salvar dados da empresa"
on public.company_data for insert to authenticated with check (id = 'salvador-brewing');
create policy "Equipe autenticada pode atualizar dados da empresa"
on public.company_data for update to authenticated using (id = 'salvador-brewing') with check (id = 'salvador-brewing');
