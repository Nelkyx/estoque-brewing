// Preencha com os dados do seu projeto Supabase (Settings > API).
// A chave anon/publishable pode ficar no frontend; NUNCA coloque service_role aqui.
window.SB_CONFIG = {
  url: "",
  anonKey: ""
};
