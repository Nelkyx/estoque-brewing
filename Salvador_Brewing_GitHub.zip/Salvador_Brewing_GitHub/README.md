# Salvador Brewing — Gestão

Aplicação web responsiva (PWA) baseada no sistema HTML existente, com:
- navegação inferior adaptada a celular;
- botões e campos confortáveis para toque;
- cache instalável (PWA);
- armazenamento local imediato;
- sincronização entre celular e notebook via Supabase;
- autenticação por e-mail e senha (sem PIN compartilhado).

## Publicar sem mensalidade

O GitHub guarda o código. Para hospedar o sistema de uma empresa, use Cloudflare Pages em vez do GitHub Pages.

1. Crie um repositório no GitHub (pode ser privado).
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Crie uma conta gratuita na Cloudflare e abra **Workers & Pages → Create → Pages → Connect to Git**.
4. Autorize o GitHub e selecione o repositório.
5. Como é um site HTML estático, deixe o comando de build vazio e use ` / ` como diretório de saída (raiz do projeto).
6. Publique. A Cloudflare fornecerá um endereço `pages.dev` para abrir no celular e no computador.

Não selecione plano pago nem cadastre forma de pagamento para começar. O plano gratuito tem limites que podem mudar; consulte os limites oficiais antes de depender do serviço para operação crítica.

## Sincronização real entre dispositivos (necessária)

O navegador de cada aparelho tem seu próprio armazenamento. A hospedagem do site não compartilha os dados. Para que o que for lançado no notebook apareça no celular:

1. Crie um projeto no Supabase no plano Free.
2. No Supabase, abra **SQL Editor**, execute todo o arquivo `supabase-schema.sql`.
3. Em **Authentication → Providers**, mantenha Email habilitado. Desative o cadastro público, se disponível.
4. Em **Authentication → Users**, crie um usuário para cada pessoa da equipe.
5. Em **Project Settings → API**, copie Project URL e a chave `anon`/`publishable`.
6. Cole esses dois valores em `config.js` nos campos `url` e `anonKey`.
7. Envie novamente `config.js` ao GitHub para que a hospedagem publique a configuração.

A chave `anon`/`publishable` é própria para frontend; as políticas RLS do SQL restringem as operações a usuários autenticados. **Nunca publique a chave `service_role`.**

## Dados já existentes e primeiro acesso

O aplicativo mantém o cache local `salvador_stock_v1` e tenta importar dados da versão anterior. Antes de conectar a nuvem, faça um backup pelo próprio sistema. Escolha o aparelho que contém os dados mais completos para fazer a primeira sincronização. Não conecte aparelhos com dados locais diferentes sem antes conferir qual conjunto deve prevalecer.

## Limitações importantes

- Sem Supabase configurado, funciona apenas localmente em cada aparelho.
- Com Supabase configurado e uma conta autenticada, os dados são compartilhados pela nuvem.
- A aplicação mantém funcionamento offline com os dados previamente carregados; alterações offline serão enviadas quando houver conexão.
- A sincronização atual grava o conjunto completo de dados da empresa. Evite editar simultaneamente em vários aparelhos; alterações concorrentes podem sobrescrever dados. Para uso simultâneo avançado, será necessário evoluir para sincronização por registros e controle de conflitos.
- O Supabase Free tem limites e pode pausar projetos inativos; mantenha backups exportados regularmente. Não trate a nuvem gratuita como substituta de backup.
